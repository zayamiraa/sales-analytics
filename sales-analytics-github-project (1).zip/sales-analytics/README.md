# 📊 Sales Performance Analytics

A complete end-to-end data analysis project built in Python, covering data ingestion, cleaning, exploratory data analysis (EDA), and visualization of 1,200+ retail sales transactions across three years.

---

## 🔍 Project Overview

This project analyzes retail sales data across multiple product categories, regions, and sales channels to uncover revenue trends, growth patterns, and the relationship between discounting and revenue performance.

**Key Questions Answered:**
- How has monthly and annual revenue trended from 2022–2024?
- Which product categories and regions drive the most revenue?
- How do Online, In-Store, and Wholesale channels compare by region?
- What is the relationship between discount rates and revenue?

---

## 📁 Project Structure

```
sales-analytics/
│
├── data/
│   ├── sales_data.csv          # Raw dataset (1,200 rows)
│   └── sales_summary.csv       # Aggregated summary export
│
├── charts/
│   ├── 01_monthly_trend.png    # Monthly revenue by year
│   ├── 02_category_revenue.png # Revenue by product category
│   ├── 03_region_channel.png   # Revenue by region & channel
│   ├── 04_discount_vs_revenue.png  # Scatter: discount vs revenue
│   └── 05_yoy_growth.png       # Year-over-year growth bars
│
├── generate_data.py            # Synthetic data generator
├── analysis.py                 # Main analysis pipeline
├── requirements.txt            # Python dependencies
└── README.md
```

---

## 📈 Sample Findings

| Metric | Value |
|--------|-------|
| Total Revenue (3 yr) | $1,843,868 |
| Total Units Sold | 17,837 |
| Avg Order Value | $1,536.56 |
| Avg Discount Rate | 12.8% |
| Top Category | Electronics (46.7%) |
| Top Region | Midwest (27.5%) |

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3.10+ | Core language |
| pandas | Data loading, cleaning, aggregation |
| NumPy | Numerical operations & imputation |
| Matplotlib | Custom chart rendering |
| Seaborn | Statistical visualizations & theming |

---

## 🚀 Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/sales-analytics.git
cd sales-analytics
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Generate the dataset
```bash
python generate_data.py
```

### 4. Run the full analysis
```bash
python analysis.py
```

Charts will be saved to the `/charts` folder. A summary CSV will be saved to `/data/sales_summary.csv`.

---

## 🧹 Data Cleaning Steps

The raw dataset intentionally includes real-world messiness:

- **Missing discount rates** (~4% of rows) → imputed with median discount
- **Missing revenue values** (~2% of rows) → recalculated from units × price × (1 − discount)
- **Duplicate order IDs** → detected and removed
- **Type coercion** → year/month integers, proper datetime column constructed

---

## 📊 Visualizations

**Monthly Revenue Trend** — Line chart comparing monthly revenue across 2022, 2023, and 2024.

**Category Revenue Breakdown** — Horizontal bar chart ranking product categories by total revenue.

**Region × Channel Heatbar** — Grouped bar chart showing how Online, In-Store, and Wholesale channels perform across all four regions.

**Discount vs. Revenue Scatter** — Scatter plot with trend line and units-sold color scale to explore discounting behavior.

**Year-over-Year Growth** — Side-by-side annual revenue bars and growth percentage bars.

---

## 📄 License

MIT License — free to use, modify, and distribute.
